package com.example.crud.mysql.controller;

import com.example.crud.mysql.model.Student;
import com.example.crud.mysql.repo.StudentRepository;
import com.example.crud.mysql.service.StudentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;



    @RestController

    public class StudentController {

        @Autowired
        private StudentService studentService;

        @GetMapping("/hello")
        public String hiController() {
            return "welcome to my controller";
        }

        @PostMapping("/add")
        public Student addStudent(@RequestBody Student student) {
            return this.studentService.addstudents(student);
        }

       @GetMapping("/students")
        public List<Student> getAllStudents() {
            return studentService.getAllStudents();
        }

        @GetMapping("/{id}")
        public Student getStudent(@PathVariable Long id) {
            Student getReponse = studentService.get(id);
            return getReponse;
        }

        @DeleteMapping("/delete")
        public String deleteStudent(@RequestBody Student student) {
            studentService.delete(student);
            return "Record deleted succesfully";
        }

        @PutMapping("/update")
        public Student updateStudent(@RequestBody Student student)
        {
            return this.studentService.update(student);
        }

}
