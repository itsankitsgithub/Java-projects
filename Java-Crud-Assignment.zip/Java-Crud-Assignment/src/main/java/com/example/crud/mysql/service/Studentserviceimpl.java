package com.example.crud.mysql.service;

import com.example.crud.mysql.model.Student;
import com.example.crud.mysql.repo.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;
import java.util.Optional;

@Service
public class Studentserviceimpl implements StudentService{
    @Autowired
    private StudentRepository studentRepository;

    //Get all the students
    public List<Student> getAllStudents() {
        List<Student> students = studentRepository.findAll();
        return students;
    }



    public Student get(Long id) {
        Optional<Student> studentResponse = studentRepository.findById(id);
        Student getResponse = studentResponse.get();
        return getResponse;
    }


    public void delete(Student student) {
        studentRepository.delete(student);
    }

    @Override
    public Student addstudents(Student student) {
        return studentRepository.save(student);
    }

    @Override
    public Student update(Student student) {
        return studentRepository.save(student);
    }


}
