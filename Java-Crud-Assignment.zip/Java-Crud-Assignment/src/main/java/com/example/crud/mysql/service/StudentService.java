package com.example.crud.mysql.service;

import com.example.crud.mysql.model.Student;
import com.example.crud.mysql.repo.StudentRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;



public interface StudentService {
    public List<Student> getAllStudents();
    public Student get(Long id);
    public void delete(Student student);


    Student addstudents(Student student);

    Student update(Student student);
}
